function searchHotels() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const hotels = document.querySelectorAll('.hotel');

  hotels.forEach(hotel => {
      const hotelName = hotel.querySelector('h3').textContent.toLowerCase();
      if (hotelName.includes(searchTerm)) {
          hotel.style.display = 'block'; 
      } else {
          hotel.style.display = 'none'; 
      }
  });
  // Показываем кнопку "Отменить поиск"
  document.getElementById('cancelSearch').style.visibility = 'visible';
  document.getElementById('cancelSearch').style.opacity = '1';
}

function handleLogin() {
    // Добавьте логику для обработки входа пользователя
    console.log("Вход"); // Временно выведите сообщение в консоль
}

function cancelSearch() {
  // Очищаем поле поиска 
  document.getElementById('searchInput').value = '';  

  const hotels = document.querySelectorAll('.hotel');
  
  // Покажите все отели
  hotels.forEach(hotel => {
    hotel.style.display = 'block'; 
  });

  // Скрываем кнопку "Отменить поиск"
  document.getElementById('cancelSearch').style.visibility = 'hidden';
  document.getElementById('cancelSearch').style.opacity = '0';
}

// Добавляем обработчик события для нажатия Enter в поле поиска
document.getElementById('searchInput').addEventListener('keydown', function(event) {
  if (event.key === 'Enter') {
    searchHotels(); 
  }
});

function showMoreHotels() {
  // Получаем контейнер для второго блока отелей
  var hotelsContainer2 = document.getElementById("hotelsContainer2");

  // Меняем отображение блока на видимое
  hotelsContainer2.style.display = "block";

  // Скрываем кнопку "Показать все"
  const showMoreButton = document.getElementById("showMoreButton");
  showMoreButton.style.display = "none"; 
}