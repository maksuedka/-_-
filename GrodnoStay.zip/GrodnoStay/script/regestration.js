const database = firebase.database();
const usersRef = database.ref('users'); 

const registerForm = document.querySelector('#registrationForm');

registerForm.addEventListener('submit', (event) => {
  event.preventDefault(); // Предотвращаем стандартную отправку формы

  const name = document.getElementById('nameInput').value;
  const email = document.getElementById('emailInput').value;
  const password = document.getElementById('passwordInput').value;

  const newUser = {
      name: name,
      email: email,
      password: password
  };

  usersRef.push(newUser); // Добавляем нового пользователя в базу данных

  // Дополнительные действия:
  // - Перенаправление на страницу входа
  // - Отображение сообщения об успешной регистрации
});